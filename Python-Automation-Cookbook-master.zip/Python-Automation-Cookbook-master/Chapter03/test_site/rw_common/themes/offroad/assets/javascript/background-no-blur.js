
$(document).ready(function(){$('.blurred').remove()})
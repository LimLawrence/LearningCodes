
$(document).ready(function(){$('.site-content').removeClass('col-md-9')
$('.site-sidebar').remove()})
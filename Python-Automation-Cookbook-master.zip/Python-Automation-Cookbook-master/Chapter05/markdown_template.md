Movies Report
=======

Date: {date}

Movies seen in the last 30 days: {num_movies}

{movies}

Total minutes: {total_minutes}

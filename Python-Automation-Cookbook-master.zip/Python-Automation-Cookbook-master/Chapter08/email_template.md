Hi {name}:

This is an email talking about **things**

### Very important info

1. One thing
2. Other thing
3. Some extra detail

Best regards,

  *The email team*

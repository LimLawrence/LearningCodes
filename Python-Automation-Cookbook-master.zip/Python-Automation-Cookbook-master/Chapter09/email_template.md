Hi!

  This is an automated email checking articles published last week containing the *keywords*: {keywords}
  in the following feeds:
{feed_list}


List of articles:
=====
{article_list}



Enjoy the read!
